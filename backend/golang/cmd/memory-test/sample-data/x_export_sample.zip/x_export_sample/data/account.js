window.YTD.account.part0 = [
  {
    account: {
      email: "john.doe@gmail.com",
      createdVia: "oauth:3033300",
      username: "JohnnyDoe",
      accountId: "123457890",
      createdAt: "2023-07-06T12:18:01.239Z",
      accountDisplayName: "JohnnyDoe",
    },
  },
];
