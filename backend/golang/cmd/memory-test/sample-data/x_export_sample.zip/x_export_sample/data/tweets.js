window.YTD.tweets.part0 = [
  {
    tweet: {
      edit_info: {
        initial: {
          editTweetIds: ["1909659312177480031"],
          editableUntil: "2025-04-08T18:27:14.000Z",
          editsRemaining: "5",
          isEditEligible: false,
        },
      },
      retweeted: false,
      source:
        '<a href="https://mobile.twitter.com" rel="nofollow">Twitter Web App</a>',
      entities: {
        hashtags: [],
        symbols: [],
        user_mentions: [
          {
            name: "User123",
            screen_name: "User123",
            indices: ["0", "12"],
            id_str: "1850280926082650113",
            id: "1850280926082650113",
          },
          {
            name: "NewsBot",
            screen_name: "NewsBot",
            indices: ["13", "26"],
            id_str: "959531564341317633",
            id: "959531564341317633",
          },
        ],
        urls: [],
      },
      display_text_range: ["0", "154"],
      favorite_count: "0",
      in_reply_to_status_id_str: "1909649453759217850",
      id_str: "1909659312177480031",
      in_reply_to_user_id: "1850280926082650113",
      truncated: false,
      retweet_count: "0",
      id: "1909659312177480031",
      in_reply_to_status_id: "1909649453759217850",
      created_at: "Tue Apr 08 17:27:14 +0000 2025",
      favorited: false,
      full_text:
        "@User123 @NewsBot The weather is beautiful today, perfect for a walk in the park. Hope everyone is having a great day!",
      lang: "en",
      in_reply_to_screen_name: "User123",
      in_reply_to_user_id_str: "1850280926082650113",
    },
  },
  {
    tweet: {
      edit_info: {
        initial: {
          editTweetIds: ["1908258125867589668"],
          editableUntil: "2025-04-04T21:39:25.000Z",
          editsRemaining: "5",
          isEditEligible: false,
        },
      },
      retweeted: false,
      source:
        '<a href="http://twitter.com/download/android" rel="nofollow">Twitter for Android</a>',
      entities: {
        hashtags: [],
        symbols: [],
        user_mentions: [
          {
            name: "User456",
            screen_name: "User456",
            indices: ["0", "15"],
            id_str: "1595082470721867777",
            id: "1595082470721867777",
          },
          {
            name: "User789",
            screen_name: "User789",
            indices: ["16", "26"],
            id_str: "85821612",
            id: "85821612",
          },
          {
            name: "UserABC",
            screen_name: "UserABC",
            indices: ["27", "37"],
            id_str: "18856868",
            id: "18856868",
          },
          {
            name: "UserXYZ",
            screen_name: "UserXYZ",
            indices: ["38", "47"],
            id_str: "249834808",
            id: "249834808",
          },
        ],
        urls: [],
      },
      display_text_range: ["0", "181"],
      favorite_count: "1",
      in_reply_to_status_id_str: "1908254285835759830",
      id_str: "1908258125867589668",
      in_reply_to_user_id: "1595082470721867777",
      truncated: false,
      retweet_count: "0",
      id: "1908258125867589668",
      in_reply_to_status_id: "1908254285835759830",
      created_at: "Fri Apr 04 20:39:25 +0000 2025",
      favorited: false,
      full_text:
        "@User456 @User789 @UserABC @UserXYZ Just finished reading an interesting book about technology and its impact on society. What are you all reading these days?",
      lang: "en",
      in_reply_to_screen_name: "User456",
      in_reply_to_user_id_str: "1595082470721867777",
    },
  },
];
