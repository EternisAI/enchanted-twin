window.YTD.like.part0 = [
  {
    like: {
      tweetId: "983726459871234567",
      fullText:
        "Just saw the most amazing sunset at the beach today! The colors were absolutely incredible. Nature never fails to amaze me. #BeachLife #Sunset",
      expandedUrl: "https://twitter.com/i/web/status/983726459871234567",
    },
  },
  {
    like: {
      tweetId: "983726459871234568",
      fullText:
        "New recipe alert! Made the best homemade pizza tonight with fresh basil from the garden. Who wants the secret recipe? #Cooking #Foodie",
      expandedUrl: "https://twitter.com/i/web/status/983726459871234568",
    },
  },
  {
    like: {
      tweetId: "983726459871234569",
      fullText:
        "Just finished reading an amazing book about space exploration. The universe is so vast and mysterious! #Space #Reading",
      expandedUrl: "https://twitter.com/i/web/status/983726459871234569",
    },
  },
  {
    like: {
      tweetId: "983726459871234570",
      fullText:
        "Morning workout complete! Nothing better than starting the day with some exercise. Who else is on their fitness journey? #Fitness #Motivation",
      expandedUrl: "https://twitter.com/i/web/status/983726459871234570",
    },
  },
  {
    like: {
      tweetId: "983726459871234571",
      fullText:
        "Just adopted the cutest puppy from the shelter! Meet Luna, my new best friend. #AdoptDontShop #PuppyLove",
      expandedUrl: "https://twitter.com/i/web/status/983726459871234571",
    },
  },
];
