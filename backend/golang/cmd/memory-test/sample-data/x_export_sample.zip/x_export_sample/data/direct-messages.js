window.YTD.direct_messages.part0 = [
  {
    "dmConversation" : {
      "conversationId" : "3895214232-1676928456225898496",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1676928456225898496",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Yup",
            "mediaUrls" : [ ],
            "senderId" : "3895214232",
            "id" : "1883269131413205222",
            "createdAt" : "2025-01-25T21:42:05.068Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3895214232",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "its so easy to take over",
            "mediaUrls" : [ ],
            "senderId" : "1676928456225898496",
            "id" : "1882849258308829593",
            "createdAt" : "2025-01-24T17:53:39.530Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3895214232",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "they dont even talk about personal finance anymore lmao",
            "mediaUrls" : [ ],
            "senderId" : "1676928456225898496",
            "id" : "1882849235424681996",
            "createdAt" : "2025-01-24T17:53:34.065Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3895214232",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "this has moved from a finance community to a communist community quickly",
            "mediaUrls" : [ ],
            "senderId" : "1676928456225898496",
            "id" : "1882849200649752911",
            "createdAt" : "2025-01-24T17:53:25.774Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "3895214232",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/ICjIPCJQuK",
                "expanded" : "https://www.reddit.com/r/FluentInFinance/",
                "display" : "reddit.com/r/FluentInFina…"
              }
            ],
            "text" : "https://t.co/ICjIPCJQuK",
            "mediaUrls" : [ ],
            "senderId" : "1676928456225898496",
            "id" : "1882849116226732213",
            "createdAt" : "2025-01-24T17:53:05.729Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  },
  {
    "dmConversation" : {
      "conversationId" : "1638683789647032320-1676928456225898496",
      "messages" : [
        {
          "messageCreate" : {
            "recipientId" : "1676928456225898496",
            "reactions" : [ ],
            "urls" : [
              {
                "url" : "https://t.co/ppjPkQBOjY",
                "expanded" : "http://dis.gd/dnsswap",
                "display" : "dis.gd/dnsswap"
              }
            ],
            "text" : "Hey there. Thanks for reaching out. I'm sorry for the inconvenience this has caused. To help isolate this further, could you try these steps:\n\n- Temporarily disable firewalls, virus scanners, and any other form of security/antivirus/adblock software; then try connecting to Discord\n- Swap DNS provider: https://t.co/ppjPkQBOjY",
            "mediaUrls" : [ ],
            "senderId" : "1638683789647032320",
            "id" : "1834056082521526601",
            "createdAt" : "2024-09-12T02:26:59.890Z",
            "editHistory" : [ ]
          }
        },
        {
          "messageCreate" : {
            "recipientId" : "1638683789647032320",
            "reactions" : [ ],
            "urls" : [ ],
            "text" : "Hello\nican't login in discord\nloading undefinitely\nworks on phone though\nregion: Mexico\nthanks",
            "mediaUrls" : [ ],
            "senderId" : "1676928456225898496",
            "id" : "1833975099671633984",
            "createdAt" : "2024-09-11T21:05:12.176Z",
            "editHistory" : [ ]
          }
        }
      ]
    }
  }
]